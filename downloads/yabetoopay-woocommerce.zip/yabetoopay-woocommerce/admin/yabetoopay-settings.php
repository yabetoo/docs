<?php

defined('ABSPATH') || exit;

return array(
  'enabled' => array(
    'title' => __('Enable/Disable', 'yabetoopay-gateway'),
    'label' => __('Enable Yabetoopay Gateway', 'yabetoopay-gateway'),
    'type' => 'checkbox',
    'description' => '',
    'default' => 'yes'
  ),

  'testmode' => array(
    'title' => __('Test Mode', 'yabetoopay-gateway'),
    'label' => __('Enable Test Mode', 'yabetoopay-gateway'),
    'type' => 'checkbox',
    'description' => __('Sets Yabetoopay into test mode', 'yabetoopay-gateway'),
    'default' => 'yes',
    'desc_tip'    => true,
  ),
  'title' => array(
    'title'       => __('(Optional) Title', 'yabetoopay-gateway'),
    'type'        => 'text',
    'description' => __('This controls the title which the user sees during checkout.', 'yabetoopay-gateway'),
    'default'     => __('Pay by Mobile Money (Yabetoopay)', 'yabetoopay-gateway'),
    'desc_tip'    => true,
  ),
  'description' => array(
    'title'       => __('(Optional) Description', 'yabetoopay-gateway'),
    'type'        => 'text',
    'description' => __('This controls the description which the user sees during checkout.', 'yabetoopay-gateway'),
    'default'     => __('Use yabetoopay to pay with your Mobile Money account', 'yabetoopay-gateway'),
    'desc_tip'    => true,
  ),
  "account_id" => array(
    'title' => __('Account ID', 'yabetoopay-gateway'),
    'type' => 'text',
    'desc_tip'    => true,
    'description' => __('Get your Account ID from your Yabetoopay dashboard', 'yabetoopay-gateway')
  ),
  'sk_test' => array(
    'title' => __('Secret Key (test)', 'yabetoopay-gateway'),
    'type' => 'password',
    'desc_tip'    => true,
    'description' => __('Get your API keys from your Yabetoopay dashboard', 'yabetoopay-gateway')
  ),
  'sk_live' => array(
    'title' => __('Secret Key (live)', 'yabetoopay-gateway'),
    'type' => 'password',
    'desc_tip'    => true,
    'description' => __('Get your API keys from your Yabetoopay dashboard', 'yabetoopay-gateway')
  ),
  'secret' => array(
    'title' => __('Secret', 'yabetoopay-gateway'),
    'type' => 'password',
    'desc_tip'    => true,
    'description' => __('Get your API keys from your Yabetoopay dashboard', 'yabetoopay-gateway')
  ),


);
