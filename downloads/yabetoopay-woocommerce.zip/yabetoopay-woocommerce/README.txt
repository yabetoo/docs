=== Yabetoopay Gateway ===
Contributors: yabetoopayteam
Tags: payment, woocommerce, yabetoopay, mobile money, credit card, bank account
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Yabetoopay permet aux entreprises de recevoir des paiements en toute sécurité par mobile money.

== Description ==

Le plugin Yabetoopay pour WooCommerce permet d'intégrer facilement la passerelle de paiement Yabetoopay à votre boutique WooCommerce.

= Caractéristiques =

* Acceptez les paiements via Moov Money, MTN Money, Orange Money, TMoney, FreeMoney
* Compatible avec WooCommerce Blocks pour une expérience de paiement moderne
* Gestion des callbacks et webhooks pour un suivi fiable des transactions
* Mode test pour valider votre intégration avant la mise en production

= Prérequis =

* WordPress 6.0 ou supérieur
* WooCommerce 6.0 ou supérieur
* PHP 7.4 ou supérieur
* Un compte Yabetoopay (https://app.yabetoo.com)

== Installation ==

1. Téléchargez le plugin et décompressez-le
2. Uploadez le dossier 'yabetoopay-gateway' dans le répertoire '/wp-content/plugins/'
3. Activez le plugin via le menu 'Extensions' dans WordPress
4. Allez dans WooCommerce > Réglages > Paiements
5. Activez "Yabetoopay" et configurez vos clés API

== Frequently Asked Questions ==

= Comment obtenir mes clés API Yabetoopay ? =

Vous pouvez obtenir vos clés API en vous connectant à votre compte sur https://app.yabetoo.com/developers

= Le plugin est-il compatible avec les devises XOF et XAF ? =

Oui, le plugin est spécifiquement conçu pour fonctionner avec les devises XOF (FCFA) et XAF (CFA).

= Comment configurer les webhooks ? =

Dans votre tableau de bord Yabetoopay, configurez l'URL de webhook qui est affichée dans les paramètres du plugin.

== Changelog ==

= 1.0.0 =
* Version initiale

== Upgrade Notice ==

= 1.0.0 =
Version initiale du plugin Yabetoopay pour WooCommerce. 